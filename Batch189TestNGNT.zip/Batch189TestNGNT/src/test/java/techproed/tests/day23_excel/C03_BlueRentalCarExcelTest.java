package techproed.tests.day23_excel;

import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.Test;
import techproed.pages.BlueRentalPage;
import techproed.utilities.ConfigReader;
import techproed.utilities.Driver;
import techproed.utilities.ExcelReader;

public class C03_BlueRentalCarExcelTest {
    BlueRentalPage blueRentalPage;
    @Test
    public void test01() {

        //BlueRentalCar adresine gidelim
        Driver.getDriver().get(ConfigReader.getProperty("blueRentalUrl"));

        //Excel dosyamizdaki tum email ve passwondler ile login oldugumuzu dogrulayalim
        String dosyaYolu="src\\test\\java\\techproed\\resources\\mysmoketestdata.xlsx";
        String sayfaIsmi="customer_info";
        ExcelReader excelReader = new ExcelReader(dosyaYolu,sayfaIsmi);

        blueRentalPage=new BlueRentalPage();

        for (int i = 1; i <= 7; i++) {
          String email=  excelReader.getCellData(i,0);
          String pasword=  excelReader.getCellData(i,1);

          blueRentalPage.loginButton.click();
          blueRentalPage.email.sendKeys(email);
          blueRentalPage.password.sendKeys(pasword, Keys.ENTER);
          blueRentalPage.loginVerify.click();
          Assert.assertTrue(blueRentalPage.profile.isDisplayed());
          blueRentalPage.logout.click();
          blueRentalPage.okButton.click();

        }

        //sayfayi kapatalim
        Driver.closeDriver();

    }
}
