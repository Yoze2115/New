package techproed.tests.day26listeners;

import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.util.NoSuchElementException;

@Listeners(techproed.utilities.Listeners.class)
public class C03_ListenersTest {

    @Test(retryAnalyzer = techproed.utilities.Listeners.class)
    public void test01() {
        System.out.println("PASS");
        Assert.assertTrue(true);
    }

    @Test(retryAnalyzer = techproed.utilities.Listeners.class)
    public void test02() {
        System.out.println("FAIL");
        Assert.assertTrue(false);
    }

}
